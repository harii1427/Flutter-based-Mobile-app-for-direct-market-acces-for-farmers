// ignore_for_file: deprecated_member_use, use_build_context_synchronously, prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:far/utils/api.dart'; // Import the Vegetable model if needed
import 'package:url_launcher/url_launcher.dart';

class DetailsPageFunctions {
  static Future<void> launchUrl(String url) async {
    try {
      if (url.startsWith('tel:')) {
        await launch(url);
      } else if (url.startsWith('https://www.instagram.com/') ||
          url.startsWith('https://wa.me/')) {
        await launch(url);
      } else {
        if (await canLaunch(url)) {
          await launch(url);
        } else {
          throw 'Could not launch $url';
        }
      }
    } catch (e) {
      // Handle error gracefully, e.g., show a snackbar or dialog to the user
    }
  }

  static Future<void> updateVegetable(
    BuildContext context,
    Vegetable vegetable,
    String name,
    String price,
    String description,
    String characteristic,
    String address, String text,
  ) async {
    final updatedFields = {
      'NAME': name,
      'PRICE': price,
      'DESCRIPTION': description,
      'CHARACTERISTIC': characteristic,
      'ADDRESS': address,
      'IMAGE': vegetable.images,
      'VIDEO': vegetable.videos,
      'PIN_CODE': vegetable.pinCode,
      ...vegetable.additionalFields,
    };

    final success = await ApiService.updateVegetable(vegetable.id, vegetable.categoryId, updatedFields);

    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Vegetable details updated successfully')),
      );
      Navigator.pop(context, updatedFields);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to update vegetable details')),
      );
    }
  }

  static Future<void> updateRoleAndAddToBuyerCollection(
    BuildContext context,
    Vegetable vegetable,
    String newRole,
  ) async {
    try {
      User? user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        String userId = user.uid;
        String email = user.email ?? '';

        // Update the role in the users collection
        await FirebaseFirestore.instance
            .collection('users')
            .doc(userId)
            .update({'role': newRole});

        // Create a new document in the buyer collection with the vegetable ID as the document ID
        await FirebaseFirestore.instance
            .collection('buyer')
            .doc(vegetable.id)
            .set({
          'userId': userId,
          'email': email,
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Role updated to $newRole and added to buyer collection')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('No user is currently logged in.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to update role and add to buyer collection: $e')),
      );
    }
  }
}
